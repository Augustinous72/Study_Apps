
import Bloglist from "./Bloglist";
import useFetch from "./useFetch";

const Home=()=>{
    const{blogs: blogs, ispending, error}=useFetch("http://localhost:8000/blogs");
return(
  <div className="Home">
    {error && <div>{error}</div>} 
    {ispending && <div>loading.....</div>}
 {blogs && <Bloglist blogs={blogs} title="All blogs!"/>} 
 {/* <Bloglist blogs={blogs.filter((blog)=>blog.Auther ==="Augustine" )} title="Augustine's blog!"/>  */}

</div>
);
}
export default Home;