import { Link } from "react-router-dom";
const notfound = () => {
return (
<div className="notfound">
<h1>Sorry this page not found</h1>
<Link to="/">Please back to home page</Link>
</div>
    );
}
 
export default notfound;