import { useState } from "react";
import {useHistory} from "react-router-dom";
export const Create = () => {
    const[title,setTitle]=useState('');
        const[body,setBody]=useState('');
             const[Auther,setAuther]=useState('Augustine');
             const[isPending,setIspending]=useState(false);
             const history=useHistory();
             const handleSubmit=(e)=>{
e.preventDefault();
const blog ={ title , body , Auther};
setIspending(true);
fetch('http://localhost:8000/blogs',{
    method: 'POST',
    headers: {"content-type":"application/json"},
    body: JSON.stringify(blog)
}).then(()=>{
  console.log("new blog added");
  setIspending(false);
//   history.go(-1);
history.push("/");
});


             }
return (
        <div className="Create">
            <h1>Add new log</h1>
            <form onSubmit={(event) => handleSubmit(event)}>
            <lebel>Blog title</lebel>
            <input type="text" value={title} onChange={(e)=>setTitle(e.target.value)} required/>
            <lebel>Blog body</lebel>
            <textarea value={body} onChange={(e)=>setBody(e.target.value)}required></textarea>
            <lebel>Blog Auther</lebel>
            <select value={Auther} onChange={(e)=>setAuther(e.target.value)}>
                <option value="Augustine" >Augustine</option>
                <option value="betty" >betty</option>
            </select>
            </form>
            {!isPending &&<button onClick={(e) => handleSubmit(e)} type="submit">Add blog</button>}
        {isPending &&<button Disabled onClick={(e) => handleSubmit(e)} type="submit">Adding blog..</button>}
        </div>
    );
}
 
export default Create;