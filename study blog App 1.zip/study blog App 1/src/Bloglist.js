import { Link } from "react-router-dom";

const Bloglist=(props)=>{
    const Blogs=props.blogs;
    const title=props.title;
    
    return(
        <div className="Bloglist">
            <h1>{title}</h1> 
        {Blogs.map((blog)=>(
            <div className="blog-prev" key={blog.id}>
            <Link to ={`/blogs/${blog.id}`}> 
              <h1>{blog.title}</h1>
              <p>{blog.body}</p>
              </Link>
              <p> Written by {blog.Auther}</p>
              
              </div>
              ))}
              </div>
    );
}
export default Bloglist;