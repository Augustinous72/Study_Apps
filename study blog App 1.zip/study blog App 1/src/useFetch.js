import { cleanup } from "@testing-library/react";
import { useState,useEffect } from "react";
const useFetch=(url)=>{
            const [blogs,setblogs]=useState(null);
            const[ispending, setIspensing]=useState(true);
            const[error,setError]=useState(null);
    useEffect(()=>{
        const Abortcon= new AbortController();
        setTimeout(()=>{
                fetch(url, {signal: Abortcon.signal})
                .then(res=>{
                    // console.log(res);
                    if(!res.ok){
                        throw Error('it could not fech the blogs');
                    }
                    return res.json();
                })
                .then(Data=>{
                    setblogs(Data);
                    setIspensing(false);
                    setError(null);
                
                })
   .catch(err =>{
       if(err.name==='AbortError'){
           console.log('fetchAborted')
       }else{
        setIspensing(false);
        setError(err.message);
        
       }
   })  

   },1000);
   return()=>console.log('cleanup');
  },[url]);
  return{blogs,ispending,error}
}
export default useFetch;